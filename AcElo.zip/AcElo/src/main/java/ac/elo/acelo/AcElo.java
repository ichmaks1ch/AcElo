package ac.elo.acelo;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AcElo extends JavaPlugin implements Listener {

    private final Map<UUID, Integer> eloMap = new HashMap<>();
    private final Map<UUID, String> rankCache = new HashMap<>();

    private File dataFile;
    private FileConfiguration dataConfig;

    private int minEloGain, maxEloGain;
    private String killerMsg, victimMsg, rankUpMsg, prefix, defaultRank;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();

        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) saveResource("data.yml", false);
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        loadEloData();
        getServer().getPluginManager().registerEvents(this, this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new EloPlaceholders(this).register();
            getLogger().info("§aPlaceholderAPI подключён!");
        }

        Bukkit.getOnlinePlayers().forEach(p -> rankCache.put(p.getUniqueId(), getRankByElo(getElo(p.getUniqueId()))));

        getLogger().info("§aAcElo v2.7.1 успешно запущен!");
    }

    @Override
    public void onDisable() {
        saveEloData();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command cmd,
                             @NotNull String label,
                             @NotNull String[] args) {

        if (!cmd.getName().equalsIgnoreCase("acelo")) return false;

        if (args.length == 0) {
            sender.sendMessage("§8▎ §x§F§F§C§C§0§0AcElo §8┃ §7Версия §f2.7.1");
            sender.sendMessage("§8▎ §f/acelo reload §7— перезагрузить конфиг");
            sender.sendMessage("§8▎ §f/acelo reset <ник> §7— сбросить ELO игроку");
            sender.sendMessage("§8▎ §f/acelo reset all §7— сбросить ELO всем");
            return true;
        }

        // reload
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("acelo.reload")) {
                sender.sendMessage("§cНет прав! (acelo.reload)");
                return true;
            }
            reloadConfig();
            loadConfigValues();
            sender.sendMessage("§a§l▎ Конфиг AcElo перезагружен!");
            return true;
        }

        // reset
        if (args[0].equalsIgnoreCase("reset") && args.length >= 2) {
            if (!sender.hasPermission("acelo.reset")) {
                sender.sendMessage("§cНет прав! (acelo.reset)");
                return true;
            }

            if (args[1].equalsIgnoreCase("all")) {
                int count = eloMap.size();
                eloMap.clear();
                rankCache.clear();
                saveEloData();

                Bukkit.getOnlinePlayers().forEach(p -> {
                    rankCache.put(p.getUniqueId(), defaultRank);
                    p.sendMessage("§c§lВнимание! Администратор сбросил ELO всем игрокам!");
                });

                sender.sendMessage("§a§l▎ ELO сброшен §e" + count + " §aигрокам!");
                return true;
            }

            String input = args[1];
            OfflinePlayer target;

            try {
                UUID uuid = UUID.fromString(input);
                target = Bukkit.getOfflinePlayer(uuid);
            } catch (IllegalArgumentException e) {
                target = Bukkit.getOfflinePlayerIfCached(input);
                if (target == null || target.getName() == null) {
                    sender.sendMessage("§cИгрок §f" + input + " §cне найден или никогда не заходил на сервер!");
                    return true;
                }
            }

            UUID uuid = target.getUniqueId();
            eloMap.put(uuid, 0);
            rankCache.put(uuid, defaultRank);

            sender.sendMessage("§a§l▎ ELO и ранг игрока §f" + (target.getName() != null ? target.getName() : input) + " §aсброшены до §e0");

            Player online = target.getPlayer();
            if (online != null) online.sendMessage("§c§lТвой ELO и ранг были сброшены администратором!");

            saveEloData();
            return true;
        }

        sender.sendMessage("§cИспользование: /acelo [reload|reset <ник>|reset all]");
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (!command.getName().equalsIgnoreCase("acelo")) return null;

        if (args.length == 1) {
            List<String> list = new ArrayList<>();
            if ("reload".startsWith(args[0].toLowerCase())) list.add("reload");
            if ("reset".startsWith(args[0].toLowerCase())) list.add("reset");
            return list;
        }

        if (args.length == 2 && "reset".equalsIgnoreCase(args[0]) && sender.hasPermission("acelo.reset")) {
            List<String> list = new ArrayList<>();
            if ("all".startsWith(args[1].toLowerCase())) list.add("all");

            for (String key : dataConfig.getKeys(false)) {
                try {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(UUID.fromString(key));
                    if (op.getName() != null && op.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                        list.add(op.getName());
                    }
                } catch (Exception ignored) {}
            }
            return list;
        }

        return Collections.emptyList();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        int gain = ThreadLocalRandom.current().nextInt(minEloGain, maxEloGain + 1);

        UUID kId = killer.getUniqueId();
        UUID vId = victim.getUniqueId();

        int oldElo = eloMap.getOrDefault(kId, 0);
        int newElo = oldElo + gain;

        eloMap.put(kId, newElo);
        eloMap.put(vId, Math.max(0, eloMap.getOrDefault(vId, 0) - gain));

        killer.sendMessage(killerMsg
                .replace("{elo}", String.valueOf(gain))
                .replace("{victim}", victim.getName()));

        victim.sendMessage(victimMsg
                .replace("{elo}", String.valueOf(gain))
                .replace("{killer}", killer.getName()));

        String oldRank = rankCache.getOrDefault(kId, defaultRank);
        String newRank = getRankByElo(newElo);

        if (!oldRank.equals(newRank)) {
            killer.sendMessage(rankUpMsg.replace("{rank}", newRank));
            rankCache.put(kId, newRank);
        }
    }

    public int getElo(UUID uuid) { return eloMap.getOrDefault(uuid, 0); }
    public String getRank(Player p) { return getRankByElo(getElo(p.getUniqueId())); }
    public Map<UUID, Integer> getEloMap() { return eloMap; }

    private String getRankByElo(int elo) {
        var s = getConfig().getConfigurationSection("ranks");
        if (s != null) {
            for (String k : s.getKeys(false)) {
                int min = getConfig().getInt("ranks." + k + ".min", 0);
                int max = getConfig().getInt("ranks." + k + ".max", Integer.MAX_VALUE);
                if (elo >= min && elo < max) {
                    return prefix + translate(getConfig().getString("ranks." + k + ".name", "§7Без ранга"));
                }
            }
        }
        return defaultRank;
    }

    private void loadConfigValues() {
        minEloGain = getConfig().getInt("min_elo_gain", 4);
        maxEloGain = getConfig().getInt("max_elo_gain", 9);
        killerMsg   = translate(getConfig().getString("messages.killer_gain", "§a+§e{elo} §aELO §8(убил §f{victim}§8)"));
        victimMsg   = translate(getConfig().getString("messages.victim_loss", "§c-§e{elo} §cELO §8(убийца §f{killer}§8)"));
        rankUpMsg   = translate(getConfig().getString("messages.rank_up", "\n§8§l▎ §x§F§F§C§C§0§0RANK UP §8§l▎\n §7Ранг повышен: §f{rank}\n"));
        prefix      = translate(getConfig().getString("prefix", ""));
        defaultRank = translate(getConfig().getString("default_rank", "§7Новичок"));
    }

    private void loadEloData() {
        eloMap.clear();
        for (String key : dataConfig.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                eloMap.put(uuid, dataConfig.getInt(key, 0));
            } catch (Exception ignored) {}
        }
    }

    private void saveEloData() {
        for (Map.Entry<UUID, Integer> e : eloMap.entrySet()) {
            dataConfig.set(e.getKey().toString(), e.getValue());
        }
        try { dataConfig.save(dataFile); } catch (IOException ignored) {}
    }

    private String translate(String s) {
        return ChatColor.translateAlternateColorCodes('§', s);
    }
}