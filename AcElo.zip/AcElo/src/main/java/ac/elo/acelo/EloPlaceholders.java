package ac.elo.acelo;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class EloPlaceholders extends PlaceholderExpansion {

    private final AcElo plugin;
    private List<Map.Entry<UUID, Integer>> cachedTop = new ArrayList<>();
    private long lastUpdate = 0L;
    private static final long CACHE_TIME = 8000L;

    public EloPlaceholders(AcElo plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "acelo"; }
    @Override public @NotNull String getAuthor() { return "You"; }
    @Override public @NotNull String getVersion() { return "2.1"; }
    @Override public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player != null) {
            if (params.equalsIgnoreCase("elo")) return String.valueOf(plugin.getElo(player.getUniqueId()));
            if (params.equalsIgnoreCase("rank")) return plugin.getRank(player);
        }

        if (System.currentTimeMillis() - lastUpdate > CACHE_TIME) {
            cachedTop = new ArrayList<>(plugin.getEloMap().entrySet());
            cachedTop.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
            lastUpdate = System.currentTimeMillis();
        }

        if (params.startsWith("top_")) {
            String[] p = params.split("_", 3);
            if (p.length != 3) return "—";
            try {
                int pos = Integer.parseInt(p[1]);
                if (pos < 1 || pos > 10 || pos > cachedTop.size()) {
                    return p[2].equals("name") ? "—" : "0";
                }
                Map.Entry<UUID, Integer> e = cachedTop.get(pos - 1);
                OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
                return p[2].equals("name")
                        ? (op.getName() != null ? op.getName() : "Неизвестно")
                        : String.valueOf(e.getValue());
            } catch (Exception ex) { return "—"; }
        }
        return null;
    }
}