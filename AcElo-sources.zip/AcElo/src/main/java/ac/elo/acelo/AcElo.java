package ac.elo.acelo;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AcElo extends JavaPlugin implements Listener {

    private final Map<UUID, Integer> eloMap = new HashMap<>();
    private final Map<UUID, String> rankCache = new HashMap<>();

    private File dataFile;
    private FileConfiguration dataConfig;

    // Сообщения и настройки из конфига
    private String msgKiller, msgVictim, msgRankUp;
    private String msgReload, msgNoPerm, msgResetPlayer, msgResetAll, msgResetNotify;
    private String msgNotFound, msgUsage, msgHelpHeader;
    private String prefix, defaultRank;
    private int minEloGain, maxEloGain;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();

        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) saveResource("data.yml", false);
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        loadEloData();
        getServer().getPluginManager().registerEvents(this, this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new EloPlaceholders(this).register();
            getLogger().info("§aPlaceholderAPI подключён!");
        }

        Bukkit.getOnlinePlayers().forEach(p -> rankCache.put(p.getUniqueId(), getRankByElo(getElo(p.getUniqueId()))));
        getLogger().info("§aAcElo v2.7 успешно запущен!");
    }

    @Override
    public void onDisable() {
        saveEloData();
    }

    private void loadConfigValues() {
        minEloGain = getConfig().getInt("min_elo_gain", 4);
        maxEloGain = getConfig().getInt("max_elo_gain", 9);
        prefix = translate(getConfig().getString("prefix", ""));
        defaultRank = translate(getConfig().getString("default_rank", "§7Новичок"));

        msgKiller       = translate(getConfig().getString("messages.killer_gain", "§a+§e{elo} §aELO"));
        msgVictim       = translate(getConfig().getString("messages.victim_loss", "§c-§e{elo} §cELO"));
        msgRankUp       = translate(getConfig().getString("messages.rank_up", "\n§8§l▎ §x§F§F§C§C§0§0RANK UP §8§l▎\n §7Ранг повышен: §f{rank}\n"));
        msgReload       = translate(getConfig().getString("messages.reload_success", "§a§l▎ Конфиг AcElo перезагружен!"));
        msgNoPerm       = translate(getConfig().getString("messages.no_permission", "§c✖ Нет прав: §f{perm}"));
        msgResetPlayer  = translate(getConfig().getString("messages.reset_player", "§a§l▎ ELO и ранг игрока §f{name} §aсброшены до §e0"));
        msgResetAll     = translate(getConfig().getString("messages.reset_all", "§a§l▎ ELO сброшен §e{count} §aигрокам!"));
        msgResetNotify  = translate(getConfig().getString("messages.reset_notify", "§c§lТвой ELO и ранг были сброшены администратором!"));
        msgNotFound     = translate(getConfig().getString("messages.player_not_found", "§c✖ Игрок §f{name} §cне найден или никогда не заходил!"));
        msgUsage        = translate(getConfig().getString("messages.usage", "§c✖ Использование: §f/acelo §7[reload|reset <ник>|reset all]"));
        msgHelpHeader   = translate(getConfig().getString("messages.help_header", "§8▎ §x§F§F§C§C§0§0AcElo §8┃ §7Версия §f2.7"));
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!cmd.getName().equalsIgnoreCase("acelo")) return false;

        if (args.length == 0) {
            sender.sendMessage(msgHelpHeader);
            sender.sendMessage("§8▎ §f/acelo reload §7— перезагрузить конфиг");
            sender.sendMessage("§8▎ §f/acelo reset <ник> §7— сбросить ELO игроку");
            sender.sendMessage("§8▎ §f/acelo reset all §7— сбросить ELO всем");
            return true;
        }

        // reload
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("acelo.reload")) {
                sender.sendMessage(msgNoPerm.replace("{perm}", "acelo.reload"));
                return true;
            }
            reloadConfig();
            loadConfigValues();
            sender.sendMessage(msgReload);
            return true;
        }

        // reset
        if (args[0].equalsIgnoreCase("reset") && args.length >= 2) {
            if (!sender.hasPermission("acelo.reset")) {
                sender.sendMessage(msgNoPerm.replace("{perm}", "acelo.reset"));
                return true;
            }

            if (args[1].equalsIgnoreCase("all")) {
                int count = eloMap.size();
                eloMap.clear();
                rankCache.clear();
                saveEloData();
                Bukkit.getOnlinePlayers().forEach(p -> {
                    rankCache.put(p.getUniqueId(), defaultRank);
                    p.sendMessage(msgResetNotify);
                });
                sender.sendMessage(msgResetAll.replace("{count}", String.valueOf(count)));
                return true;
            }

            String input = args[1];
            OfflinePlayer target;

            try {
                UUID uuid = UUID.fromString(input);
                target = Bukkit.getOfflinePlayer(uuid);
            } catch (IllegalArgumentException e) {
                target = Bukkit.getOfflinePlayerIfCached(input);
                if (target == null || target.getName() == null) {
                    sender.sendMessage(msgNotFound.replace("{name}", input));
                    return true;
                }
            }

            UUID uuid = target.getUniqueId();
            eloMap.put(uuid, 0);
            rankCache.put(uuid, defaultRank);

            sender.sendMessage(msgResetPlayer.replace("{name}", target.getName() != null ? target.getName() : input));

            Player online = target.getPlayer();
            if (online != null) online.sendMessage(msgResetNotify);

            saveEloData();
            return true;
        }

        sender.sendMessage(msgUsage);
        return true;
    }

    // ТАБ-КОМПЛИТ
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (!command.getName().equalsIgnoreCase("acelo")) return null;

        if (args.length == 1) {
            List<String> list = new ArrayList<>();
            if ("reload".startsWith(args[0].toLowerCase())) list.add("reload");
            if ("reset".startsWith(args[0].toLowerCase())) list.add("reset");
            return list;
        }

        if (args.length == 2 && "reset".equalsIgnoreCase(args[0]) && sender.hasPermission("acelo.reset")) {
            List<String> list = new ArrayList<>();
            if ("all".startsWith(args[1].toLowerCase())) list.add("all");

            for (String key : dataConfig.getKeys(false)) {
                try {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(UUID.fromString(key));
                    if (op.getName() != null && op.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                        list.add(op.getName());
                    }
                } catch (Exception ignored) {}
            }
            return list;
        }

        return Collections.emptyList();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        int gain = ThreadLocalRandom.current().nextInt(minEloGain, maxEloGain + 1);

        UUID kId = killer.getUniqueId();
        UUID vId = victim.getUniqueId();

        int oldElo = eloMap.getOrDefault(kId, 0);
        int newElo = oldElo + gain;

        eloMap.put(kId, newElo);
        eloMap.put(vId, Math.max(0, eloMap.getOrDefault(vId, 0) - gain));

        killer.sendMessage(msgKiller.replace("{elo}", String.valueOf(gain)));
        victim.sendMessage(msgVictim.replace("{elo}", String.valueOf(gain)));

        String oldRank = rankCache.getOrDefault(kId, defaultRank);
        String newRank = getRankByElo(newElo);

        if (!oldRank.equals(newRank)) {
            killer.sendMessage(msgRankUp.replace("{rank}", newRank));
            rankCache.put(kId, newRank);
        }
    }

    // Публичные методы
    public int getElo(UUID uuid) { return eloMap.getOrDefault(uuid, 0); }
    public String getRank(Player p) { return getRankByElo(getElo(p.getUniqueId())); }
    public Map<UUID, Integer> getEloMap() { return eloMap; }

    private String getRankByElo(int elo) {
        var s = getConfig().getConfigurationSection("ranks");
        if (s != null) {
            for (String k : s.getKeys(false)) {
                int min = getConfig().getInt("ranks." + k + ".min", 0);
                int max = getConfig().getInt("ranks." + k + ".max", Integer.MAX_VALUE);
                if (elo >= min && elo < max) {
                    return prefix + translate(getConfig().getString("ranks." + k + ".name", "§7Без ранга"));
                }
            }
        }
        return defaultRank;
    }

    private String translate(String s) {
        return ChatColor.translateAlternateColorCodes('§', s);
    }

    private void loadEloData() {
        eloMap.clear();
        for (String key : dataConfig.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                eloMap.put(uuid, dataConfig.getInt(key, 0));
            } catch (Exception ignored) {}
        }
    }

    private void saveEloData() {
        for (Map.Entry<UUID, Integer> e : eloMap.entrySet()) {
            dataConfig.set(e.getKey().toString(), e.getValue());
        }
        try { dataConfig.save(dataFile); } catch (IOException ignored) {}
    }
}